module.exports = {
  mongoURI: ' mongodb://localhost/MS-4',
  secretKey: 'key#$#hello',
};
